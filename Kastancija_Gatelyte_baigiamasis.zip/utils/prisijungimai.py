SMTP_SERVER = "mail.kaste.smshostingas.lt"
USERNAME = "ligonine@kaste.smshostingas.lt"
PASSWORD = "ligonine"